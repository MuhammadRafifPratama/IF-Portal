package com.example.tubes02_prototype;

public class InputLogin {
    protected String email;
    protected String password;
    protected String role;

    public InputLogin(String email, String password, String role) {
        this.email = email;
        this. password = password;
        this.role = role;
    }
}
