package com.example.tubes02_prototype;

public interface IMainActivity {
    void updatePengumumanList();
    void updateTagList();
}
