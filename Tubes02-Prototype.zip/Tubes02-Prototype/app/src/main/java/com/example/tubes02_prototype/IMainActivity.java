package com.example.tubes02_prototype;

import java.util.List;

public interface IMainActivity {
    void updatePengumumanList(List<Pengumuman> pengumumans);
    void updateTagList(Tag[] tags);
}
