package com.example.tubes02_prototype;

public class Author {
    String id;
    String author;

    public Author(String id, String author) {
        this.id = id;
        this.author = author;
    }
}
